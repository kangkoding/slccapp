@extends('admin.template.admin')
@section('content')
        <div class="row">
            <div class="col-md-12">
            	<div class="panel panel-default">
            		<div class="panel-heading">
            			Panel 1
            		</div>
            		<div class="panel-body">
            			<form action="">
            				<div class="form-group">
            					<label for="#">Title</label>
            					<input type="text" name="" class="form-control" value="">
            				</div>
            				<div class="form-group">
            					<label for="#">Kategori Post</label>
            					<select name="id_kategori" id="" class="form-control">
            						<option value=""></option>
            					</select>
            				</div>
							<div class="form-group">
            					<label for="#">Kategori Post</label>
            					<select name="id_kategori" id="" class="form-control">
            						<option value=""></option>
            					</select>
            				</div>
            			</form>
            		</div>
            	</div>
            </div>
        </div>
@endsection