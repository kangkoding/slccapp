@extends('admin.template.admin')
@section('content')
<center><div class="well"><h1>Selamat datang di Admin Dashboard</h1></div></center>
@endsection