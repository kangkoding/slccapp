@extends('admin.template.admin')
@section('content')
    <script src="<?php echo base_url();?>assets/js/tinymce/tinymce.min.js"></script>
    <script>
        tinymce.init({
          selector: 'textarea',
          height: 500,
          menubar: false,
          plugins: [
            'advlist autolink lists link image charmap print preview anchor textcolor',
            'searchreplace visualblocks code fullscreen',
            'insertdatetime media table contextmenu paste code wordcount'
          ],
          toolbar: 'insert | undo redo |  formatselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat',

        });
    </script>
    <h2 style="margin-top:0px">Page <?php echo $button ?></h2>
    <ul class="nav nav-tabs">
      <li class="active"><a data-toggle="tab" href="#home">Bahasa Indonesia</a></li>
      <li><a data-toggle="tab" href="#menu1">English</a></li>
    </ul>
    <form action="<?php echo $action; ?>" method="post">
    <div class="tab-content">
      <div id="home" class="tab-pane fade in active" style="padding:10px;margin-bottom:10px;background-color:white;border:solid 1px #dcdcdc">
        <div class="form-group">
            <label for="varchar">Judul <?php echo form_error('judul') ?></label>
            <input type="text" class="form-control" name="judul" id="judul" placeholder="Judul" value="<?php echo $judul; ?>" />
        </div>
        <div class="form-group">
            <label for="isi">Isi <?php echo form_error('isi') ?></label>
            <textarea class="form-control" rows="15" name="isi" id="isi" placeholder="Isi"><?php echo $isi; ?></textarea>
        </div>
        <input type="hidden" name="id" value="<?php echo $id; ?>" />
      </div>
      <div id="menu1" class="tab-pane fade" style="padding:10px;margin-bottom:10px;background-color:white;border:solid 1px #dcdcdc">
        <div class="form-group">
            <label for="varchar">Title <?php echo form_error('title') ?></label>
            <input type="text" class="form-control" name="title" id="title" placeholder="title" value="<?php echo $title; ?>" />
        </div>
        <div class="form-group">
            <label for="content">Content <?php echo form_error('content') ?></label>
            <textarea class="form-control" rows="15" name="content" id="content" placeholder="content"><?php echo $content; ?></textarea>
        </div>
      </div>
    </div>
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('admin/page') ?>" class="btn btn-default">Cancel</a>
	</form>
@endsection