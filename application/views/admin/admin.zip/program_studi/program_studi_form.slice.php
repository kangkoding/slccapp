@extends('admin.template.admin')
@section('content')
    <script src="<?php echo base_url();?>assets/js/tinymce/tinymce.min.js"></script>
    <script>
        tinymce.init({
          selector: 'textarea',
          height: 500,
          menubar: false,
          plugins: [
            'advlist autolink lists link image charmap print preview anchor textcolor',
            'searchreplace visualblocks code fullscreen',
            'insertdatetime media table contextmenu paste code wordcount'
          ],
          toolbar: 'insert | undo redo |  formatselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat',

        });
    </script>
        <h2 style="margin-top:0px"><?php echo $button ?> Program Studi</h2>
        <form action="<?php echo $action; ?>" method="post">
    <ul class="nav nav-tabs">
      <li class="active"><a data-toggle="tab" href="#home">Bahasa Indonesia</a></li>
      <li><a data-toggle="tab" href="#menu1">English</a></li>
    </ul>

    <div class="tab-content">
      <div id="home" class="tab-pane fade in active" style="padding:10px;margin-bottom:10px;background-color:white;border:solid 1px #dcdcdc">
	    <div class="form-group">
            <label for="varchar">Nama Program <?php echo form_error('nama_program') ?></label>
            <input type="text" class="form-control" name="nama_program" id="nama_program" placeholder="Nama Program" value="<?php echo $nama_program; ?>" />
        </div>
	    <div class="form-group">
            <label for="deskripsi">Deskripsi <?php echo form_error('deskripsi') ?></label>
            <textarea class="form-control" rows="15" name="deskripsi" id="deskripsi" placeholder="Deskripsi"><?php echo $deskripsi; ?></textarea>
        </div>
	    <input type="hidden" name="id" value="<?php echo $id; ?>" />
      </div>
      <div id="menu1" class="tab-pane fade" style="padding:10px;margin-bottom:10px;background-color:white;border:solid 1px #dcdcdc">
        <div class="form-group">
            <label for="varchar">Name <?php echo form_error('program_name') ?></label>
            <input type="text" class="form-control" name="program_name" id="program_name" placeholder="Name" value="<?php echo $program_name; ?>" />
        </div>
        <div class="form-group">
            <label for="description">Description <?php echo form_error('description') ?></label>
            <textarea class="form-control" rows="15" name="description" id="description" placeholder="Description"><?php echo $description; ?></textarea>
        </div>
        <input type="hidden" name="id" value="<?php echo $id; ?>" />  
      </div>
    </div>
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('admin/program_studi') ?>" class="btn btn-default">Cancel</a>
	</form>
@endsection