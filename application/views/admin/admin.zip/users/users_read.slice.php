@extends('admin.template.admin')
	@section('content')
    <h2 style="margin-top:0px">Detail Pengguna</h2>
    <table class="table table-striped">
	    <tr><td>Username</td><td><?php echo $username; ?></td></tr>
	    <tr><td>Email</td><td><?php echo $email; ?></td></tr>
	    <tr><td>Last Login</td><td><?php echo $last_login; ?></td></tr>
	    <tr><td>Name</td><td><?php echo $full_name; ?></td></tr>
	    <tr><td>Phone</td><td><?php echo $phone; ?></td></tr>
	    <tr><td>Asal</td><td><?php echo $origin; ?></td></tr>
	    <tr><td>Tempat Lahir</td><td><?php echo $birth_place; ?></td></tr>
	    <tr><td>Tanggal Lahir</td><td><?php echo $birth_date; ?></td></tr>
	    <tr><td>Nomor KTP</td><td><?php echo $id_number; ?></td></tr>
	    <tr><td>Jenis Kelamin</td><td><?php echo $gender; ?></td></tr>
	    <tr><td>Alamat</td><td><?php echo $address; ?></td></tr>
	    <tr><td>Asal Kota</td><td><?php echo $city_id; ?></td></tr>
	    <tr><td>Kode Pos</td><td><?php echo $postal_code; ?></td></tr>
	    <tr><td>Nomor HP</td><td><?php echo $mobile_number; ?></td></tr>
	    <tr><td>Negara Asal</td><td><?php echo $country; ?></td></tr>
	    <tr><td>Status Perkawinan</td><td><?php echo $marriage_status; ?></td></tr>
	    <tr><td>Agama</td><td><?php echo $religion; ?></td></tr>
	    <tr><td>Pendidikan</td><td><?php echo $pendidikan; ?></td></tr>
	    <tr><td>NIM</td><td><?php echo $nim; ?></td></tr>
	    <tr><td>IPK</td><td><?php echo $ipk; ?></td></tr>
	    <tr><td>Bidang</td><td><?php echo $bidang; ?></td></tr>
	    <tr><td>Disabilitas</td><td><?php echo $ket_disabilitas; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('admin/users') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
	@endsection