@extends('admin.template.admin')
@section('content')
    <script src="<?php echo base_url();?>assets/js/tinymce/tinymce.min.js"></script>
    <script>
        tinymce.init({
          selector: 'textarea',
          height: 500,
          menubar: false,
          plugins: [
            'advlist autolink lists link image charmap print preview anchor textcolor',
            'searchreplace visualblocks code fullscreen',
            'insertdatetime media table contextmenu paste code wordcount'
          ],
          toolbar: 'insert | undo redo |  formatselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat',

        });
    </script>
    <h2 style="margin-top:0px">Post <?php echo $button ?></h2>
    <form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data">
    <ul class="nav nav-tabs">
      <li class="active"><a data-toggle="tab" href="#home">Bahasa Indonesia</a></li>
      <li><a data-toggle="tab" href="#menu1">English</a></li>
    </ul>

    <div class="tab-content">
      <div id="home" class="tab-pane fade in active" style="padding:10px;margin-bottom:10px;background-color:white;border:solid 1px #dcdcdc">
            <div class="form-group">
                <label for="varchar">Judul <?php echo form_error('judul') ?></label>
                <input type="text" class="form-control" name="judul" id="judul" placeholder="Judul" value="<?php echo $judul; ?>" />
            </div>
            <div class="form-group">
                <label for="isi">Isi <?php echo form_error('isi') ?></label>
                <textarea class="form-control" rows="15" name="isi" id="isi" placeholder="Isi"><?php echo $isi; ?></textarea>
            </div>
            <?php if(!empty($featured_image)): ?>
                <img src="<?php echo base_url('assets/images/').$featured_image ?>" alt="" style="height:200px;border:solid 5px silver">
            <?php endif; ?>
            <div class="form-group">
                <label for="varchar">Featured Image <?php echo form_error('featured_image') ?></label>
                <input type="file" name="featured_image" class="form-control">
                <input type="hidden" name="old_image" value="<?php echo $featured_image ?>">
            </div>
            <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
      </div>
      <div id="menu1" class="tab-pane fade" style="padding:10px;margin-bottom:10px;background-color:white;border:solid 1px #dcdcdc">
            <div class="form-group">
                <label for="varchar">Title <?php echo form_error('title') ?></label>
                <input type="text" class="form-control" name="title" id="title" placeholder="Title" value="<?php echo $title; ?>" />
            </div>
            <div class="form-group">
                <label for="isi">Content <?php echo form_error('content') ?></label>
                <textarea class="form-control" rows="15" name="content" id="content" placeholder="Content"><?php echo $title; ?></textarea>
            </div>
            <?php if(!empty($featured_image)): ?>
                <img src="<?php echo base_url('assets/images/').$featured_image ?>" alt="" style="height:200px;border:solid 5px silver">
            <?php endif; ?>
      </div>
    </div>
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('admin/post') ?>" class="btn btn-default">Cancel</a>
	</form>
@endsection