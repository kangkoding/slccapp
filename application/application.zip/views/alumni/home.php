<section class="content">
	<center>
		<div class="well">
			<h1>Selamat datang Alumni SWU</h1>
		</div>
	</center>
</section>